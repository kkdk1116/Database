select *
from flight_TBL
where flightStartPoint like '����%'
order by flightStartDate asc

select flightCost, count(*) as ���ݺ�����
from flight_TBL
group by flightCost

select flightCost, count(*) as ���ݺ�����, sum(flightCost) as �հ�
from flight_TBL
where flightCost>=100000
group by flightCost
having count(*)<=4

select *
from flight_TBL
where flightStartDate between '2022-01-01' and '2022-04-30' 
order by flightStartDate desc


