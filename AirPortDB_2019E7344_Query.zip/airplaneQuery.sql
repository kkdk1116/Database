select case when grouping(airplaneKind) = 1 then '�հ�'
else airplaneKind
end as airplaneKind
,case when grouping(airplaneCost) = 1 then '�Ұ�'
else cast(airplaneCost as nvarchar)
end as airplaneCost
, count(*) as ����, sum(airplaneCost) as �հ�
from airplane_TBL
where airplaneKind in ('Boeing 747', 'a380')
group by rollup(airplaneKind, airplaneCost)