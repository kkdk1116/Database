select *
from seat_TBL
where seatGrade='E'
order by airplaneNumber, seatNumber asc


select *
from seat_TBL
where seatNumber like '%C'
order by airplaneNumber, seatNumber asc


select *
from seat_TBL
where seatGrade='B' and seatNumber like '%A'
order by airplaneNumber, seatNumber asc
