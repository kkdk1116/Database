select *
from member_TBL
where memberName='����'

select *
from member_TBL
where memberAddress like '���%'

select *
from member_TBL
where memberName like '��%' and memberAddress like '����%'

select distinct memberAddress
from member_TBL

select *
from member_TBL
where memberBirth between '1981-01-01' and '2010-12-31'
order by memberBirth asc

select *
from member_TBL
where memberPhone is null
